package client;

import client.GUI.MainGuiWindow;

public class MainClient {

    public static void main(String[] args) {
        new MainGuiWindow();
    }
}
