package client.GUI;

import client.GUI.CreateReservationWindowGUI;
import client.HotelController;

import javax.swing.*;

/**
 * @author Catalin Udrea
 * A class extending CreateReservationWindowGUI
 * So much work.
 */
public class Search extends CreateReservationWindowGUI {

    public Search (JTabbedPane parent, HotelController hc) {
        super(parent, hc);
    }

}